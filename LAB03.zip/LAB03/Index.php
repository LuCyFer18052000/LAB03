<?php include_once("header.php"); ?>
  <ul class="menu">
    <li>
      <a href="/LAB03/list_product.php">Danh sach san pham</a>
    </li>
    <li>
      <a herf="/LAD03/add_product.php">Ten san pham</a>
    </li>
  </ul>
<?php include_once("footer.php"); ?>
