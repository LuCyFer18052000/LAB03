<!DOCTYPE html>
<html lang="vi">
<head>
  <meta charset="utf-8">
  <meta name="author" content="nguyenthaithanhlong"/>
  <link rel="stylesheet" href="/LAB03/Site.css"/>
  <title>project training - website ban hang</title>
</head>
<body>
  <div id="wapper">
    <h2>project training - xay dung website ban hang</h2>
  </div>
</body>  